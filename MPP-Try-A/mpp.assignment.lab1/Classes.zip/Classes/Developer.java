
public class Developer {
	private String name;

	public String getName() {
		return name;
	}
}
