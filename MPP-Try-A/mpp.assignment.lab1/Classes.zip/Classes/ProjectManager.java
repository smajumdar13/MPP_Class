
public class ProjectManager {
	private String name;

	public String getName() {
		return name;
	}
}
