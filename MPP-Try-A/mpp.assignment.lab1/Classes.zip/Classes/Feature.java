
public class Feature {
	private int effortRequired;
	private Developer Assignee;
	private double PercentageOfWorkCompleted;

	public int getEffortRequired() {
		return effortRequired;
	}

	public Developer getAssignee() {
		return Assignee;
	}

	public double getPercentageOfWorkCompleted() {
		return PercentageOfWorkCompleted;
	}
}
