
public class Sprint {
	private Feature[] features;
	private double amountOfWorkCompleted;

	public double getAmountOfWorkCompleted() {
		return amountOfWorkCompleted;
	}

	public Feature[] getFeatures() {
		return features;
	}

}
