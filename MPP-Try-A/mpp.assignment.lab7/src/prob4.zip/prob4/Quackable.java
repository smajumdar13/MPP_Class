package prob4;

interface Quackable {
	default void quack() {
		System.out.println("I can quack");
	}
	
	
}
