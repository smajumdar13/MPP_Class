package prob4;

public class Quack implements Quackable {

	@Override
	public void quack() {
		System.out.println("Quack by quacking");
		
	}

}
