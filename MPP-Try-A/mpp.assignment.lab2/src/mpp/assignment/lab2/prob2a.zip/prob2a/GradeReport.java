package mpp.assignment.lab2.prob2a;

public class GradeReport {
	private Student student;
	private String grade;
	public GradeReport(Student student) {
		// TODO Auto-generated constructor stub
		this.student = student;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}

}
