This package has been packaged as a jar file
for use in the LecturesAndLabs project,
in lesson10.lecture.jdbc.framework.business

