package lesson8.exercise_2_soln.test;

//@FunctionalInterface
public interface Example1 {
	public String toString();
}
