package lesson5.exercise_2_soln;

public interface Iface1 {
	int myMethod(int x);
}
