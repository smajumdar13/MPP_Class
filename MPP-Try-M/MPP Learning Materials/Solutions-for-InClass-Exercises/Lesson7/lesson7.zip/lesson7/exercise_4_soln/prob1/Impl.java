package lesson7.exercise_4_soln.prob1;

public class Impl implements Iface1, Iface2 {
	//implementation or redeclaration required
	public int myMethod(int x) {
		return x;
	}
	
}
	

