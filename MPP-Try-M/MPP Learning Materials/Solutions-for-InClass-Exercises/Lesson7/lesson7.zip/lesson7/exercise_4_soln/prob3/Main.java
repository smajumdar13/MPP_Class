package lesson7.exercise_4_soln.prob3;


public class Main {

	public static void main(String[] args) {
		Impl ob = new Impl();
		System.out.println(ob.myMethod(2));

	}

}
