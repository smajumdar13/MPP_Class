package lesson7.exercise_4_soln.prob2;

public class Impl implements Iface1, Iface2 {
   //implementation required
	public int myMethod(int x) {
		return x;
	}

}
