package lesson9.labsolns.prob10;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
