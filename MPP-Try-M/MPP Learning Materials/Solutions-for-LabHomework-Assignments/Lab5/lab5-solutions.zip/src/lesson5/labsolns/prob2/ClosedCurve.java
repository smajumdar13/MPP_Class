package lesson5.labsolns.prob2;

public interface ClosedCurve {	
	double computeArea();
}
