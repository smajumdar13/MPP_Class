package lesson2.labsolns.prob2A_external_constructorsetter;

public class StudentAndReport {
	public Student student;
	public GradeReport report;
	public StudentAndReport(Student s, GradeReport g) {
		student = s;
		report = g;
	}
}
