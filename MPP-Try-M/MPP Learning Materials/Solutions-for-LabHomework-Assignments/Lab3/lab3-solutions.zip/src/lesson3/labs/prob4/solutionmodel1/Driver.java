package lesson3.labs.prob4.solutionmodel1;

public class Driver {

	public Driver() {
		
	}
	
	public static void main(String[] args) {
		
		Property[] properties = { new House(9000), new Condo(2), new Trailer() };
		double totalRent = Admin.computeTotalRent(properties);
		System.out.println(totalRent);		
		
//		Object[] objects = { new House(9000), new Condo(2), new Trailer() };
//		double totalRent = Admin.computeTotalRent(objects);
//		System.out.println(totalRent);

	}	

}
