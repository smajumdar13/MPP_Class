package lesson3.labs.prob1.usinginheritancewithsameclassstrategy;

public class PersonWithJob extends Person {
	private double salary;

	public PersonWithJob(String name, double salary) {
		super(name);
		this.salary = salary;
	}
	
	public double getSalary() { return salary; }
	
	@Override
	public boolean equals(Object obj) {
		if(this == obj) { return true; }
		if(obj == null) { return false; }
		if(this.getClass() != obj.getClass()) { return false; }
		PersonWithJob pwj = (PersonWithJob)obj;
		boolean isEqual = (this.getName().equals(pwj.getName()) && this.getSalary() == pwj.getSalary());
		return isEqual;
	}	
	
	public static void main(String[] args) {
		Person p1 = new PersonWithJob("Joe", 30000);
		Person p2 = new Person("Joe");
		//As PersonWithJobs, p1 should NOT be equal to Person, p2 ==> output: false and false
		System.out.println("p1.equals(p2)? " + p1.equals(p2));
		System.out.println("p2.equals(p1)? " + p2.equals(p1));
	}	
}
