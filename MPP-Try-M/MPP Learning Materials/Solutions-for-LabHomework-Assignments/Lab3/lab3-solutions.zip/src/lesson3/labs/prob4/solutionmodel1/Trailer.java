package lesson3.labs.prob4.solutionmodel1;

public class Trailer extends Property {
	private TrailerPark trailerPark;

	public Trailer() {

	}

	public Trailer(int propertyId, Address address, double rent) {
		super(propertyId, address, rent);
	}

	/**
	 * @return the trailerPark
	 */
	public TrailerPark getTrailerPark() {
		return trailerPark;
	}

	/**
	 * @param trailerPark the trailerPark to set
	 */
	public void setTrailerPark(TrailerPark trailerPark) {
		this.trailerPark = trailerPark;
	}

	/**
	 * @return the rent
	 */
	@Override
	public double computeRent() {
		return 500.00;
	}

}
