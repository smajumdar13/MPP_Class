/**
 * 
 */
package lesson3.labs.prob4.solutionmodel1;

/**
 * @author obi
 *
 */
public abstract class Property {
	private int propertyId;
	protected double rent;
	private Address address;
	
	/**
	 * Default constructor
	 */
	public Property() {
		
	}

	/**
	 * @param propertyId
	 * @param address
	 */
	public Property(int propertyId, Address address, double rent) {
		this.propertyId = propertyId;
		this.address = address;
		this.rent = rent;
	}

	/**
	 * @return the propertyId
	 */
	public int getPropertyId() {
		return propertyId;
	}

	/**
	 * @param propertyId the propertyId to set
	 */
	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(Address address) {
		this.address = address;
	}

	/**
	 * @return the rent
	 */
	public double getRent() {
		return computeRent();
	}
	
	protected abstract double computeRent();
	
}
