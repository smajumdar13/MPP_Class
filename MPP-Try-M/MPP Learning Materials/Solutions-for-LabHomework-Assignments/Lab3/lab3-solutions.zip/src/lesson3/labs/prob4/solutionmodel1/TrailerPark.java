package lesson3.labs.prob4.solutionmodel1;

public class TrailerPark {
	private int trailerParkId;
	private String trailerParkName;
	private Address address;
	/**
	 * 
	 */
	public TrailerPark() {

	}
	/**
	 * @param trailerParkId
	 * @param trailerParkName
	 * @param address
	 */
	public TrailerPark(int trailerParkId, String trailerParkName, Address address) {
		this.trailerParkId = trailerParkId;
		this.trailerParkName = trailerParkName;
		this.address = address;
	}
	/**
	 * @return the trailerParkId
	 */
	public int getTrailerParkId() {
		return trailerParkId;
	}
	/**
	 * @param trailerParkId the trailerParkId to set
	 */
	public void setTrailerParkId(int trailerParkId) {
		this.trailerParkId = trailerParkId;
	}
	/**
	 * @return the trailerParkName
	 */
	public String getTrailerParkName() {
		return trailerParkName;
	}
	/**
	 * @param trailerParkName the trailerParkName to set
	 */
	public void setTrailerParkName(String trailerParkName) {
		this.trailerParkName = trailerParkName;
	}
	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
}
