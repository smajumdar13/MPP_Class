package lesson3.labs.prob2.solutionmodel1;

public class Apartment {
	private double rent;
	public Apartment(double rent) {
		this.rent = rent;
	}
	public double getRent() {
		return rent;
	}
}
