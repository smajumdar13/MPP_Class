package lesson3.labs.prob1.usingcompositionwithsameclassstrategy;

public class PersonWithJobInNeighbourhood {
	private PersonWithJob pwj;
	private boolean isInMyNeighborhood;
	
	public PersonWithJobInNeighbourhood(String name, double salary, boolean isInMyNeighborhood) {
		this.pwj = new PersonWithJob(name, salary);
		this.isInMyNeighborhood = isInMyNeighborhood;
	}

	public boolean getIsInMyNeighborhood() { return this.isInMyNeighborhood; }
	
	@Override
	public boolean equals(Object obj) {
		if(this == obj) { return true; }
		if(obj == null) { return false; }
		if(this.getClass() != obj.getClass()) { return false; }
		PersonWithJobInNeighbourhood pwjin = (PersonWithJobInNeighbourhood)obj;
		boolean isEqual = (pwjin.pwj.equals(pwj) && pwjin.isInMyNeighborhood == this.isInMyNeighborhood);
		return isEqual;
	}
	
	public static void main(String[] args) {
		PersonWithJob p1 = new PersonWithJob("Joe", 50000);
		PersonWithJobInNeighbourhood p2 = new PersonWithJobInNeighbourhood("Joe", 50000, true);
		// As PersonsWithJob and PersonWithJobInNeighbourhood, p1 should NOT be equal to p2, since the classes are different
		System.out.println("p1.equals(p2)? " + p1.equals(p2));
		System.out.println("p2.equals(p1)? " + p2.equals(p1));
		
		PersonWithJobInNeighbourhood p3 = new PersonWithJobInNeighbourhood("Joe", 50000, true);
		PersonWithJobInNeighbourhood p4 = new PersonWithJobInNeighbourhood("Joe", 50000, true);
		// As PersonWithJobInNeighbourhood, p3 should be equal to p4, since the classes & data values are same
		System.out.println("p3.equals(p4)? " + p3.equals(p4));
		System.out.println("p4.equals(p3)? " + p4.equals(p3));	

	}

}
