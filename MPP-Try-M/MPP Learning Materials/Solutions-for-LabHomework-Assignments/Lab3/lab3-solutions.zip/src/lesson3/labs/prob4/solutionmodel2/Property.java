package lesson3.labs.prob4.solutionmodel2;

abstract public class Property {
	abstract double computeRent();
}
