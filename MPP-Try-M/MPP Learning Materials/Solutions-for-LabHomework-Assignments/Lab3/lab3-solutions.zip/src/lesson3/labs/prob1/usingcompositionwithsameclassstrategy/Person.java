package lesson3.labs.prob1.usingcompositionwithsameclassstrategy;

public class Person {
	private String name;

	public Person(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(this == obj) { return true; }
		if(obj == null) { return false; }		
		if(this.getClass() != obj.getClass()) { return false; }
		Person otherPerson = (Person)obj;
		boolean isEqual = this.name.equals(otherPerson.name);
		return isEqual;
	}
}
