package lesson3.labs.prob4.solutionmodel1;

public class Condo extends Property {
	private int numberOfFloors;
	/**
	 * 
	 */
	public Condo() {
		super();
	}
	
	public Condo(int numFloors) {
		this.numberOfFloors = numFloors;
	}

	
	/**
	 * @param propertyId
	 * @param address
	 */
	public Condo(int propertyId, Address address, double rent) {
		super(propertyId, address, rent);
	}
	/**
	 * @param propertyId
	 * @param address
	 * @param numberOfFloors
	 * @param rent
	 */
	public Condo(int propertyId, Address address, int numFloors, double rent) {
		super(propertyId, address, rent);
		this.numberOfFloors = numFloors;
		this.rent = rent;
	}
	/**
	 * @return the numberOfFloors
	 */
	public int getNumberOfFloors() {
		return numberOfFloors;
	}
	/**
	 * @param numberOfFloors the numberOfFloors to set
	 */
	public void setNumberOfFloors(int numberOfFloors) {
		this.numberOfFloors = numberOfFloors;
	}
	/**
	 * @return the rent
	 */
	@Override
	public double computeRent() {
		double rent = (400 * numberOfFloors);
		return rent;
	}
	
}
