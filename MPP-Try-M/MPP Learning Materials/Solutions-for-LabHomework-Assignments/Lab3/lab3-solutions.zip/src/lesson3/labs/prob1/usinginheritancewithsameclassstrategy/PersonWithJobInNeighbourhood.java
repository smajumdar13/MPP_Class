package lesson3.labs.prob1.usinginheritancewithsameclassstrategy;

public class PersonWithJobInNeighbourhood extends PersonWithJob {
	private boolean isInMyNeighborhood;
	
	public PersonWithJobInNeighbourhood(String name, double salary, boolean isInMyNeighborhood) {
		super(name, salary);
		this.isInMyNeighborhood = isInMyNeighborhood;
	}

	public boolean getIsInMyNeighborhood() { return this.isInMyNeighborhood; }
	
	public static void main(String[] args) {
		PersonWithJob p1 = new PersonWithJob("Joe", 50000);
		PersonWithJobInNeighbourhood p2 = new PersonWithJobInNeighbourhood("Joe", 50000, true);
		// As PersonsWithJob, p2 should be equal to p1, since names match and salaries match
		System.out.println("p1.equals(p2)? " + p1.equals(p2));
		System.out.println("p2.equals(p1)? " + p2.equals(p1));
		// Unfortunately, this still results in a problem
		// Solution: Declare the class, PersonWithJob as final, preventing any further inheritance
		// Question: What if we DO NOT want to declare PersonWithJob as final?
		// Answer: We then use Composition instead of Inheritance
	}

}
