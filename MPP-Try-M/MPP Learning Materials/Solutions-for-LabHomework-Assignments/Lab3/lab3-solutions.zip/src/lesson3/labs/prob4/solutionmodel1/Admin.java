package lesson3.labs.prob4.solutionmodel1;

public class Admin {

	public Admin() {
		
	}
	
	public static double computeTotalRent(Property[] properties) {
		double totalRent = 0;
		for(Property p : properties) {
			// totalRent += p.computeRent();
			totalRent += p.getRent();
		}
		return totalRent;
		
//		for (Object o : properties) {
//			if (o instanceof House) {
//				House h = (House) o;
//				totalRent += h.computeRent();
//			}
//			else if (o instanceof Condo) {
//				Condo h = (Condo) o;
//				totalRent += h.computeRent();
//			}
//			else if (o instanceof Trailer) {
//				Trailer h = (Trailer) o;
//				totalRent += h.computeRent();
//			}	
//		}
//		return totalRent;
	}	

}
