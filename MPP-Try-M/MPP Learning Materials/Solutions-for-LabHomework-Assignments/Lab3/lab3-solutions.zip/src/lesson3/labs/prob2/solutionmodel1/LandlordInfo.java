package lesson3.labs.prob2.solutionmodel1;

import java.util.List;

public class LandlordInfo {
	private List<Building> buildings;
	public LandlordInfo(List<Building> b) {
		buildings = b;
	}
	public double calcProfits() {
		double profit = 0.0;
		for(Building build : buildings) {
			profit += build.calcProfit();
		}
		return profit;
	}
}
