/**
 * 
 */
package lesson3.labs.prob4.solutionmodel1;

/**
 * @author obi
 *
 */
public class House extends Property {
	private double lotSize;
	/**
	 * 
	 */
	public House() {
		super();
	}
	/**
	 * @param propertyId
	 * @param address
	 */
	public House(int propertyId, Address address, double rent) {
		super(propertyId, address, rent);
	}
	/**
	 * @param lotSize
	 * @param rent
	 */
	public House(double lotSize) {
		super();
		this.lotSize = lotSize;
	}
	/**
	 * @param lotSize
	 * @param rent
	 */
	public House(int propertyId, Address address, double lotSize, double rent) {
		super(propertyId, address, rent);
		this.lotSize = lotSize;
	}
	/**
	 * @return the lotSize
	 */
	public double getLotSize() {
		return lotSize;
	}
	/**
	 * @param lotSize the lotSize to set
	 */
	public void setLotSize(double lotSize) {
		this.lotSize = lotSize;
	}
	/**
	 * @return the rent
	 */
	@Override
	public double computeRent() {
		double rent = (0.1 * this.lotSize);
		return rent;
	}
}
