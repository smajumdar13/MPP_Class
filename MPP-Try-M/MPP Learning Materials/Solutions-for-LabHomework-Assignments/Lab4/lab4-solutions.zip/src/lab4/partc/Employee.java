package lab4.partc;

import java.time.LocalDate;

public abstract class Employee {
	private String empId;
	private String name;
	
	public Employee(String empId, String name) {
		this.empId = empId;
		this.name = name;
	}
	
	public String getEmpId() { return empId; }
	public String getName() { return name; }

	public void print() {
		//LocalDate now = LocalDate.now();
		LocalDate now = LocalDate.of(2018, 1, 1);
		//System.out.println(calcCompensation(now.getMonthValue(), now.getYear()));
		Paycheck paycheck = calcCompensation(now.getMonthValue(), now.getYear());
		paycheck.print();
	}
	public Paycheck calcCompensation(int month, int year) {
		double grossPay = calcGrossPay(month, year);
		return new Paycheck(this, grossPay, Tax.FICA, Tax.State, Tax.Local, Tax.Medicare, Tax.SocialSecurity);
	}

	abstract public double calcGrossPay(int month, int year);
}
