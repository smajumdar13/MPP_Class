package lab4.partc;

public class Salaried extends Employee {
	private double monthlySalary;
	public Salaried(String empId, String name, double salary) {
		super(empId, name);
		monthlySalary = salary;
	}
	
	@Override
	public double calcGrossPay(int month, int year) {
		return monthlySalary;
	}
}
