package lab4.partc.extpkg;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import lab4.partc.Commissioned;
import lab4.partc.Employee;
import lab4.partc.Hourly;
import lab4.partc.Order;
import lab4.partc.Salaried;

public class HRApp {

	public static void main(String[] args) {
		
		Employee[] employees = new Employee[3];
		Employee bobSalariedEmp = employees[0] = new Salaried("101", "Bob", 50000.0);
		
		Employee anaHourlyEmp = employees[1] = new Hourly("102", "Anna", 10.0, 40);
		
		List<Order> orders = Arrays.asList(
				new Order(LocalDate.of(2017, 12, 1), 20000.0),
				new Order(LocalDate.of(2018, 2, 6), 10000.0),
				new Order(LocalDate.of(2017, 12, 24), 15000.0),
				new Order(LocalDate.of(2018, 1, 10), 25000.0),
				new Order(LocalDate.of(2018, 2, 18), 50000.0)
		);
		
		Employee carlosCommEmp = employees[2] = new Commissioned("103", "Carlos", 0.10, 50000.0, orders);
		
		bobSalariedEmp.print();
		//bobSalariedEmp.calcCompensation(2, 2018).print();		
		anaHourlyEmp.print();
		carlosCommEmp.print();
	}

}
