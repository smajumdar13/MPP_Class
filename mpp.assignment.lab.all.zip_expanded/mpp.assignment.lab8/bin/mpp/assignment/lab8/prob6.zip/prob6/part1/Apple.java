package mpp.assignment.lab8.prob6.part1;

public class Apple {
	private double weight;

	public double getWeight() {
		return weight;
	}

//	public void setWeight(double weight) {
//		this.weight = weight;
//	}
	

}
