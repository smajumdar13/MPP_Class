package mpp.assignment.lab8.prob6.part1;

import java.util.Comparator;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Main {

	public static void main(String[] args) {

		// prob6.partA.

		Function<Employee, String> getName1 = e -> e.getName();
		// Method reference type: Class::instanceMethod
		Function<Employee, String> getName2 = Employee::getName;

		// prob6.partB.
		BiConsumer<Employee, String> setName1 = (e, s) -> e.setName(s);
		// Method reference type: Class::instanceMethod
		BiConsumer<Employee, String> setName2 = Employee::setName;

		// prob6.partC
		BiFunction<String, String, Integer> compareTo1 = (String s1, String s2) -> s1.compareTo(s2);
		// Method reference type: Class::instanceMethod
		BiFunction<String, String, Integer> compareTo2 = String::compareTo;

		// prob6.partD
		BiFunction<Integer, Integer, Double> pow1 = (Integer x, Integer y) -> Math.pow(x, y);
		// Method reference type: Class::staticMethod
		BiFunction<Integer, Integer, Double> pow2 = Math::pow;

		// prob6.partE
		Function<Apple, Double> getWeight1 = a -> a.getWeight();
		// Method reference type: Class::instanceMethod
		Function<Apple, Double> getWeight2 = Apple::getWeight;

		// prob6.partF
		Function<String, Integer> parseInt1 = (String x) -> Integer.parseInt(x);
		// Method reference type: Class::staticMethod
		Function<String, Integer> parseInt2 = Integer::parseInt;

		// prob6.partG
		
		EmployeeNameComparator comp = new EmployeeNameComparator();
		Comparator<Employee> compare1 =  (e1, e2) -> comp.compare(e1,e2);
		// Method reference type: object::instanceMethod
		Comparator<Employee> compare2 =  comp::compare;

	}

}
