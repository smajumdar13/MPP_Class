package mpp.assignment.lab8.prob6.part2;

import java.util.Comparator;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Examples {
	void evaluator() {

		/// test your other method references

		// prob6.partA.
		
		// Method reference type: Class::instanceMethod
		Function<Employee, String> getName2 = Employee::getName;
		
		System.out.println(getName2.apply(new Employee("Steve", 100000)));

		// prob6.partB.
		
		// Method reference type: Class::instanceMethod
		BiConsumer<Employee, String> setName2 = Employee::setName;

		Employee emp1  = new Employee("Steve", 100000);
		setName2.accept(emp1, "New Steve");
		System.out.println(emp1.getName());
		
		// prob6.partC
		
		// Method reference type: Class::instanceMethod
		BiFunction<String, String, Integer> compareTo2 = String::compareTo;
		System.out.println(compareTo2.apply("Steve", "Job"));

		// prob6.partD
		
		// Method reference type: Class::staticMethod
		BiFunction<Integer, Integer, Double> pow = Math::pow;
		System.out.println(pow.apply(3, 3));

		// prob6.partE
		
		// Method reference type: Class::instanceMethod
		Function<Apple, Double> getWeight2 = Apple::getWeight;
		
		System.out.println(getWeight2.apply(new Apple(3.0)));

		// prob6.partF
		
		// Method reference type: Class::staticMethod
		Function<String, Integer> parseInt2 = Integer::parseInt;
		System.out.println(parseInt2.apply("3"));
		
		
		// prob6.partG

		EmployeeNameComparator comp = new EmployeeNameComparator();
		
		// Method reference type: object::instanceMethod
		Employee emp2  = new Employee("Steve", 1000);
		Employee emp3  = new Employee("Steve", 1000);
		Comparator<Employee> compare2 = comp::compare;
		System.out.println(compare2.compare(emp2, emp3));
	}
}
