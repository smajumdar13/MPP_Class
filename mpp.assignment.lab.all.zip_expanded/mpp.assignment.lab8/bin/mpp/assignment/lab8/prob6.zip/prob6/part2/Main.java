package mpp.assignment.lab8.prob6.part2;

import java.util.Comparator;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Main {

	public static void main(String[] args) {

		Examples examples = new Examples();
		examples.evaluator();

	}

}
