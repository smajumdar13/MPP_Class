package mpp.assignment.lab2.prob2b;

public class Orderline {
	private Order order;
	public Orderline(Order order){
		this.order = order;
	}
}
