package lesson9.labs.prob10.parta;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
