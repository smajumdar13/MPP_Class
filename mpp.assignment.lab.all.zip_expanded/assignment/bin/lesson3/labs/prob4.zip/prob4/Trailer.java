package lesson3.labs.prob4;

public class Trailer extends Property {
	private final static double RENT = 500;
	@Override
	public double computeRent() {
		// TODO Auto-generated method stub
		return RENT;
	}

}
