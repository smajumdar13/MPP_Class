package lesson5.labs.prob2;

interface FlyBehavior {
	void fly();
}
