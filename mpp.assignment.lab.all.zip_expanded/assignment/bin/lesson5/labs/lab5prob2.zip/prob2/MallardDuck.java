package lesson5.labs.prob2;

public class MallardDuck extends Duck {

	public MallardDuck() {
		
		flyBehavior= new FlyWithWings();
		quackBehavior = new Quack();
	}

	@Override
	public void display() {
		System.out.println("This is Mallard duck");
		
	}

}
