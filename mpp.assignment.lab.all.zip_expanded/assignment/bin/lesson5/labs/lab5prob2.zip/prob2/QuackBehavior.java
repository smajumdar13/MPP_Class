package lesson5.labs.prob2;

interface QuackBehavior {
	void quack();
}
