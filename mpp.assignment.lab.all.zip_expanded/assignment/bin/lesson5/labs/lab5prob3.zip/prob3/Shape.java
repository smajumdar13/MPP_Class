package lesson5.labs.prob3;

public interface Shape {
	double computeArea();
	
}
