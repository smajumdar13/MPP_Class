package Lesson8.Prob1.b;

import java.util.Random;
import java.util.function.Supplier;

public class Equivalent {

	public static void main(String[] args) {
		
		// calling method random() to generate random number
		Supplier<Double> random = () -> Equivalent.random();
		System.out.println(random.get());
	}
	
	// inner class in method random()
	public static double random() {
		class randomNumber implements Supplier<Double> {
			public Double get() {
				Random random = new Random();
				return random.nextDouble();
			}
		}
		return new randomNumber().get();
	}
}
