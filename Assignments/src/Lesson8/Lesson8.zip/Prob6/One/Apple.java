package Lesson8.Prob6.One;

public class Apple {
	private double weight;

	public double getWeight() {
		return weight;
	}

}
